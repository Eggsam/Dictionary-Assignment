#pragma once
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <regex>


using namespace std;


// Word (names for classes are self-explanatory) 
class Word
{
private: //good practice to keep variables private
	string _stringName;
	string _definition;

public:
	Word() {} // no-args constructor, allows you to return an empty object

	Word(string name, string definition) // holds different parts of word from dictionary
	{
		_stringName = name;
		_definition = definition;
	}

	void setStringName(string);
	virtual void setDefinition(string);
	virtual string getStringName();
	virtual string getDefinition();
	virtual bool isNoun();
	virtual bool isVerb();
	virtual bool isAdverb();
	virtual bool isAdjective();
	virtual bool isPreposition();
	virtual bool isMiscword();
	virtual bool isPropernoun();
	virtual bool isPalindrome();
	Word printDefinition(string getStringName(), string  getDefinition());
};

class Noun : virtual public Word //defines Noun class
{
public:
	virtual bool isNoun()
	{
		return true;
	}
	virtual string getDefinition()
	{
		string n = "n. ";
		n.append(Word::getDefinition());
		return n;
	}

};

class Verb : virtual public Word
{
public:
	virtual bool isVerb()
	{
		return true;
	}
	virtual string getDefinition()
	{
		string v = "v. ";
		v.append(Word::getDefinition());
		return v;
	}
};
class Adverb : public Word
{
	virtual bool isAdverb()
	{
		return true;
	}
	virtual string getDefinition()
	{
		string av = "av. ";
		av.append(Word::getDefinition());
		return av;
	}
};
class Adjective : public Word
{
	virtual bool isAdjective()
	{
		return true;
	}
	virtual string getDefinition()
	{
		string ad = "ad. ";
		ad.append(Word::getDefinition());
		return ad;
	}

};
class Miscword : public Word
{
	virtual bool isMiscword()
	{
		return true;
	}
	virtual string getDefinition()
	{
		string m = "Misc. ";
		m.append(Word::getDefinition());
		return m;
	}
};
class Preposition : public Miscword
{
	virtual bool isPreposition()
	{
		return true;
	}
	virtual string getDefinition()
	{
		string pre = "Prep. ";
		pre.append(Word::getDefinition());
		return pre;
	}
};
class ProperNoun : public Noun
{
	virtual bool isProperNoun()
	{
		return true;
	}
	virtual string getDefinition()
	{
		string pro = "Prop. ";
		pro.append(Word::getDefinition());
		return pro;
	}
};

class NounAndVerb : public Noun, public Verb
{
public:

	NounAndVerb()
	{

	}
	NounAndVerb(string name, string definition) : Word(name, definition)
	{
		//name = getStringName();
		//definition = getDefinition();
	}
	virtual bool isNoun()
	{
		return true;
	}
	virtual bool isVerb()
	{
		return true;
	}
	//virtual bool isNounAndVerb();// {
		//if (isVerb() == true && isNoun() == true)
		//{
		//	cout << getStringName();
		//		return true;
		//}
		//lse
		//{
		//	return false;
		//}
	//}
	
	virtual string getDefinition()
	{
		string nV = "NandV. ";
		nV.append(Word::getDefinition());
		return nV;
	}

};

void Word::setStringName(string name)
{
	_stringName = name;
}

string Word::getStringName()
{
	return _stringName;
}

void Word::setDefinition(string definition)
{
	_definition = definition;
}


string Word::getDefinition()
{
	return _definition;
}


Word Word::printDefinition(string getstringName(), string getDefition())
{
	return Word(getstringName(), getDefition());
}

bool Word::isNoun()
{
	return false;

}
bool Word::isVerb()
{
	return false;
}
bool Word::isAdverb()
{
	return false;
}
bool Word::isAdjective()
{
	return false;
}
bool Word::isPreposition()
{
	return false;
}
bool Word::isMiscword()
{
	return false;
}
bool Word::isPropernoun()
{
	return false;
}
bool Word::isPalindrome()
{
	string word = getStringName();
	string palindrome = getStringName();

	reverse(palindrome.begin(), palindrome.end());

	if (palindrome == word)
	{
		return true;
	}
	else
	{
		return false;
	}
}
//bool Word::isNounAndVerb()
//{//
//	if (isVerb() == true && isNoun() == true)
//	{
//		//cout << getStringName();
//		return true;
//	}
//	else
//	{
//		return false;
//	}
//}

//virtual bool NounandVerb::isNounandVerb()
