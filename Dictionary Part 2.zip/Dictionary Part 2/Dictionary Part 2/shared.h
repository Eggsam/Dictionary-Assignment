#ifndef SHARED_H
#define SHARED_H

#include <string>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

class Word //defines word class
{
private: //good practice to keep variables private
	string _stringName;
	string _definition;

public:
	Word() {} // no-args constructor, allows you to return an empty object

	Word(string name, string definition) // holds different parts of word from dictionary
	{
		_stringName = name; 
		_definition = definition;
	}

	void setStringName(string); 
	void setDefinition(string);
	string getStringName(); 
	string getDefinition();
	virtual bool isPalindrome();
	virtual bool isNoun();
	virtual bool isVerb();
	virtual bool isAdverb();
	virtual bool isAdjective();
	virtual bool isPreposition();
	virtual bool isMiscword();
	virtual bool isPropernoun();
	Word printDefinition(string _stringName, string _definition); 
};

class Dictionary //defines Dictionary class
{
private:
	vector<Word*> _wordVector; // vector to store Word objects

public:
	int Load(string filename); 
	Word Find(string keyword); 
	Word Searchz(); 
	Word Searchq();
	int getCount();
};

class Noun : virtual public Word //defines Noun class
{
public: 
	virtual bool isNoun()
	{
		return true;
	}
};

class Verb : virtual public Word
 {
 public: 
	 virtual bool isVerb()
	 {
		 return true;
	 }	
};
class Adverb : public Word
{
	virtual bool isAdverb()
	{
		return true;
	}
};
class Adjective : public Word
{
	virtual bool isAdjective()
	{
		return true;
	}
};
class Miscword : public Word
{
	virtual bool isMiscword()
	{
		return true;
	}
};
class Preposition : public Miscword
{
	virtual bool isPreposition()
	{
		return true;
	}
};
class ProperNoun : public Noun
{
	virtual bool isProperNoun()
	{
		return true;
	}
};

class NounandVerb : virtual public Noun, virtual public Verb
{
public:
	//NounandVerb::NounandVerb(bool isNoun, bool isVerb : Noun(isNoun) , Verb(isVerb)
	//{
	//}		
	virtual bool isNounandVerb()
	{
		return true;
	}
}

#endif //SHARED_H

