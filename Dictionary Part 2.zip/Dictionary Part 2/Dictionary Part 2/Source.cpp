
#include "shared.h"
#include <iostream>
#include <string>
#include <algorithm>


using namespace std;

int main()
{
	Dictionary d;
	Word wd;
	string searchWord; 
	bool userChoiceB;
	int userChoiceN;
	
	cout << "Loading dictionary file...\n";
	cout << "\nload: " + to_string(d.Load("dictionary.txt")) + "\n";
	cout << "getcount: " + to_string(d.getCount()) + "\n";

	//C:\\Users\\sammo\\Desktop\\Object-Oriented Programming with C++\\Dict\\

	userChoiceB = 1;

	while (userChoiceB == 1)
	{
		cout << "\n Enter [1] for a word you wish to find\n Enter [2] for word's with more than 3'zs \n Enter [3] for word's that have a 'q' without a following 'u'\n	";
		cin >> userChoiceN;
		while (1)
		{
			if (cin.fail() || userChoiceN > 3) //error-handling
			{
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cout << "\n Invalid option, Choose either [1] Word you wish to find\n [2] Word's with more than 3'z\n [3] Word's that have a 'q' without a following 'u'\n	" << endl;
				cin >> userChoiceN;
			}
			if (!cin.fail())
				break;
		}
					
		if (userChoiceN == 1)
		{
			cout << "\n Enter a word you wish to find: "; 
			cin >> searchWord;
			transform(searchWord.begin(),searchWord.end(), searchWord.begin(), ::tolower); //error-handling
			wd = d.Find(searchWord);					 
			if ((wd.getStringName()) != "")
			{
				cout << "\n Found...\n ";
				cout << wd.getStringName() << "\n ";
				cout << wd.getDefinition() << "\n ";
				
			}
			else if ((wd.getStringName()) == "")
			{
				cout << "\n This word is not in the dictionary\n";
		
			}
		}
		else if (userChoiceN == 2) 
		{
			cout << "\n Searching for words with more than 3Z's... \n";
			wd = d.Searchz();

			if ((wd.getStringName()) != "")
			{
				cout << "\n Found...\n";
				cout << "\n " << wd.getStringName() << "\n";
				cout << "\n " << wd.getDefinition() << "\n";			
			}
			else if ((wd.getStringName()) == "")
			{
				cout << "\n No words containing more than 3 z's";
			}
		}
		else if (userChoiceN == 3) 
		{
			cout << "\n Searching for words that have a 'q' without a following 'u'...  \n";
			wd = d.Searchq();

			if ((wd.getStringName()) != "")
			{
				cout << "\n Found...\n";
				cout << "\n " << wd.getStringName() << "\n";
				cout << "\n " << wd.getDefinition() << "\n";				
			}
			else if ((wd.getStringName()) == "")
			{
				cout << "\n No words containing more than 3 z's";
			}			
		}
		cout << "\n Do you wish to continue running the dictionary\n Continue[1] Terminate[0]\n	"; //Keeps the program running while user chooses too
		cin >> userChoiceB;
		while (1) //error-handling
		{
			if (cin.fail() )
			{
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cout << "\n Invalid option\n Choose either Continue[1] or Terminate[0]\n	" << endl;
				cin >> userChoiceN;
			}
			if (!cin.fail())
				break;
		}

	}
}
