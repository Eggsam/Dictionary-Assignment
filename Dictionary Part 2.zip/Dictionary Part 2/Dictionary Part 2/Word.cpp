#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <regex>
#include "shared.h"

using namespace std;

// Word (names for classes are self-explanatory) 

void Word::setStringName(string name)
{
	_stringName = name;
}

string Word::getStringName()
{
	return _stringName;
}

void Word::setDefinition(string definition)
{
	_definition = definition;
}

string Word::getDefinition()
{
	return _definition;
}

bool Word::isPalindrome()
{
	return false;
}

Word Word::printDefinition(string _stringName, string _definition)
{
	return Word(_stringName, _definition);
}

bool Word::isNoun()
{
	return false;
}
bool Word::isVerb()
{
	return false;
}
bool Word::isAdverb()
{
	return false;
}
bool Word::isAdjective()
{
	return false;
}
bool Word::isPreposition()
{
	return false;
}
bool Word::isMiscword()
{
	return false;
}
bool Word::isPropernoun()
{
	return false;
}
virtual bool NounandVerb::isNounandVerb()


