#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <regex>
#include "shared.h"
using namespace std;

//Dictionary 
int Dictionary::Load(string filename)
{	
	string fileLine;   // declare variable for holding current line from file
	ifstream dictFile(filename, ifstream::in); // Open file in read mode
	int count = 0;  // declare variable for the count
	string savedLines[3];

	if (dictFile.is_open()) // checks file is open
	{
		string name = savedLines[0]; // declares array to save the lines into
		string definition = savedLines[1];
		string type = savedLines[2];

		while (getline(dictFile, fileLine)) // gets lines from dictionary and saves it to fileLine in a loop
		{									 
			//savedLines[count++] = fileLine; // ++ increments through saved lines from count value (0) and saves it to fileLine 
			
			savedLines[0] = fileLine;
			getline(dictFile, fileLine);
			savedLines[1] = fileLine;
			getline(dictFile, fileLine);
			savedLines[2] = fileLine;
			getline(dictFile, fileLine);
	
			
			if (savedLines[2] == "n")
			{
				Noun* noun = new Noun();
				noun->setDefinition(savedLines[1]);
				noun->setStringName(savedLines[0]);
				//noun->printDefinition(name, definition);
				//Set noun word and defintion here ----
				//pushback object to vector
				_wordVector.push_back(noun);
			}
			else if (savedLines[2] == "v")
			{
				Verb* verb = new Verb();
				verb->setDefinition(savedLines[1]);
				verb->setStringName(savedLines[0]);
				_wordVector.push_back(verb);
			}
			else if (savedLines[2] == "adv")
			{
				Adverb* adverb = new Adverb();
				adverb->setDefinition(savedLines[1]);
				adverb->setStringName(savedLines[0]);
				_wordVector.push_back(adverb);
			}
			else if (savedLines[2] == "adj")
			{
				Adjective* adjective = new Adjective();
				adjective->setDefinition(savedLines[1]);
				adjective->setStringName(savedLines[0]);
				_wordVector.push_back(adjective);
			}
			else if (savedLines[2] == "prep")
			{
				Preposition* preposition = new Preposition();
				preposition->setDefinition(savedLines[1]);
				preposition->setStringName(savedLines[0]);
				_wordVector.push_back(preposition);
			}
			else if (savedLines[2] == "misc")
			{
				Miscword* miscword = new Miscword();
				miscword->setDefinition(savedLines[1]);
				miscword->setStringName(savedLines[0]);
				_wordVector.push_back(miscword);
			}
			else if (savedLines[2] == "pn")
			{
				ProperNoun* propernoun = new ProperNoun();
				propernoun->setDefinition(savedLines[1]);
				propernoun->setStringName(savedLines[0]);
				propernoun->setStringName(savedLines[0]);
				_wordVector.push_back(propernoun);
			}
			else if (savedLines[2] == "n_and_v")
			{
				//NounandVerb*;
			}
		}
		dictFile.close(); // close file
	}
	else
	{
		cout << "Error: Can't access dictionary file: " + filename;
	}

	return _wordVector.size(); //

}

int Dictionary::getCount()  //tells you how many items are in dictionary
{
	return _wordVector.size();
}


Word Dictionary::Find(string keyword)
{
	vector<Word*>::iterator it = _wordVector.begin();  //Iterators through a vector from the begining
	while (it != _wordVector.end())					// while not = to the end of the vector continue
	{
			if (((*it)->getStringName()) == keyword)		// *it points to the value in _wordVector and .getStringName gets the name of current match 
 		{
			return *(*it);				// returns match
		}
		it++;		// cotinues iterating

	}
	return Word(); 
}
Word Dictionary::Searchz()
{
	vector<Word*>::iterator it = _wordVector.begin(); // go through word letter by letter and count 
	regex z("[a-zA-z]{0,}z{1,}[a-zA-z]{0,}z{1,}[a-zA-z]{0,}z{1,}[a-zA-z]{0,}"); //regex pattern for words containing more than 3z's
	while (it != _wordVector.end()) //same code as find
	{
		if (regex_match((*it)->getStringName(), z))	//if there is a regex_match return the string name of that match
		{
			return **it;
			
		}
		it++;		
	}
	return Word();
}

Word Dictionary::Searchq()
{
	vector<Word*>::iterator it = _wordVector.begin(); //same code as Find
	regex q("[a-zA-Z]{0,}q{1,}[^u]"); //regex pattern for q without a u following
	while (it != _wordVector.end())
	{
		if (regex_match((*it)->getStringName(), q))
		{
			return **it;
		}
		it++;
	}
	return Word();
}
